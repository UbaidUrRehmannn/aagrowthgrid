"use strict";
exports.id = 943;
exports.ids = [943];
exports.modules = {

/***/ 5066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Split__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8636);
/* harmony import */ var _data_sections_about_info1_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5862);




const AboutIntro = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "intro-section section-padding pb-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-3 col-md-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "htit sm-mb30",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: _data_sections_about_info1_json__WEBPACK_IMPORTED_MODULE_3__/* .title */ .TN
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-8 offset-lg-1 col-md-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Split__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "wow txt mb-10 words chars splitting",
                                        "data-splitting": true,
                                        children: _data_sections_about_info1_json__WEBPACK_IMPORTED_MODULE_3__/* .paragraph1 */ .X8
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "wow txt words chars splitting",
                                        "data-splitting": true,
                                        children: _data_sections_about_info1_json__WEBPACK_IMPORTED_MODULE_3__/* .paragraph2 */ .i7
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutIntro);


/***/ }),

/***/ 476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

/* eslint-disable @next/next/no-img-element */ 
const PagesHeader = ()=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: "pages-header circle-bg valign",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row justify-content-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-10",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "cont mt-100 mb-50 text-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "color-font fw-700",
                                    children: "Amazon Marketing Services"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-10",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "img",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/img/slid/about.jpg",
                                    alt: ""
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "half sub-bg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "circle-color",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "gradient-circle"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "gradient-circle two"
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PagesHeader);


/***/ }),

/***/ 810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ services)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/data/sections/featuresAms.json
const featuresAms_namespaceObject = JSON.parse('[{"id":1,"image":"/img/service-2.svg","title":"Fix Existing Ad Campaigns","content1":"Your sponsored product listings are the key to sales. If they\'re not pulling their weight, they\'re useless. We fully optimize your listings before we push traffic to them."},{"id":2,"image":"/img/service-2.svg","title":"Build Customized PPC Strategies","content1":"We know that no two businesses are the same, which is why we create individual sponsored ad campaigns catered to your brands needs."},{"id":3,"image":"/img/service-2.svg","title":"Maximize ROAS","content1":"We make tweaks to your sponsored ad campaigns to increase the return you get on your ad spend and reduce overall costs."},{"id":4,"image":"/img/service-2.svg","title":"Improve Organic Ranking","content1":"Magic doesn\'t happen overnight. We constantly track, tweak, measure, and optimize your PPC campaigns to reduce ACOS and make sure all sponsored ads are performing at their best."},{"id":5,"image":"/img/service-2.svg","title":"Analyze and Monitor Campaigns","content1":"We make tweaks to your sponsored ad campaigns to increase the return you get on your ad spend and reduce overall costs."},{"id":6,"image":"/img/service-2.svg","title":"Manage All Amazon Sponsored Ads","content1":"We oversee the entire PPC campaign process from start to finish and help you create high-converting sponsored product ads, sponsored brand ads, product display ads, and video ads"},{"id":7,"image":"/img/service-2.svg","title":"Identify Incremental Sales Opportunities","content1":"We dig into your data and find key components that can be optimized to increase sales.."},{"id":8,"image":"/img/service-2.svg","title":"Reduce ACOS, Improve ROI","content1":"We\'ll run a health check on your existing PPC campaigns to gain insight on what\'s working and what\'s not before starting new campaigns."},{"id":9,"image":"/img/service-2.svg","title":"Building a Sustainable Brand","content1":"Sustainability begins with optimizing your product listings and identifying relevant and profitable traffic to send to your sponsored product campaigns."},{"id":10,"image":"/img/service-2.svg","title":"Increase Sales & Scalability","content1":"We know what makes sponsored product listings convert. Not only do we ensure your PPC campaigns are reaching the right people, but we optimize your product pages to improve ranking, relevancy and brand scalability."}]');
;// CONCATENATED MODULE: ./src/components/ams-Services/services.jsx



// import featuresData from "../../data/sections/features.json";

const Services = ({ style , lines  })=>{
    const delays = [
        ".3s",
        ".6s",
        ".9s",
        "1.2s",
        "1.5s",
        "1.8s"
    ];
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: `services bords section-padding ${style === "4item" ? "lficon" : lines ? "" : "pt-0"}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-8 col-md-10",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "sec-head text-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                className: "wow fadeIn",
                                "data-wow-delay": ".5s",
                                children: "Our services"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        style === "4item",
                        featuresAms_namespaceObject.map((feature, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-6 wow fadeInLeft",
                                "data-wow-delay": delays[index],
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "item-box",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "cont",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                children: feature.title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: feature.content1
                                            })
                                        ]
                                    })
                                })
                            }, feature.id)
                        )
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const services = (Services);


/***/ }),

/***/ 5862:
/***/ ((module) => {

module.exports = JSON.parse('{"TN":"Who We Are ?","X8":"AA Growth Grid is a one stop strategic consulting and Amazon marketing agency assisting clients on and off Amazon.","i7":"The company aims to help small business owners and online brands that are struggling to keep up with the massive changes in the market maximize their potential as well as expand their reach and scale with amazon marketing and full service account management."}');

/***/ })

};
;