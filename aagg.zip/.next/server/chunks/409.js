"use strict";
exports.id = 409;
exports.ids = [409];
exports.modules = {

/***/ 9127:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ clients)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/data/sections/clients.json
const clients_namespaceObject = JSON.parse('[{"id":1,"lightImage":"/img/clients/brands/light/01.png","darkImage":"/img/clients/brands/dark/01.png","url":"www.Vie.com"},{"id":2,"lightImage":"/img/clients/brands/light/02.png","darkImage":"/img/clients/brands/dark/02.png","url":"www.Vie.com"},{"id":3,"lightImage":"/img/clients/brands/light/03.png","darkImage":"/img/clients/brands/dark/03.png","url":"www.Vie.com"},{"id":4,"lightImage":"/img/clients/brands/light/04.png","darkImage":"/img/clients/brands/dark/04.png","url":"www.Vie.com"},{"id":5,"lightImage":"/img/clients/brands/light/05.png","darkImage":"/img/clients/brands/dark/05.png","url":"www.Vie.com"},{"id":6,"lightImage":"/img/clients/brands/light/06.png","darkImage":"/img/clients/brands/dark/06.png","url":"www.Vie.com"},{"id":7,"lightImage":"/img/clients/brands/light/07.png","darkImage":"/img/clients/brands/dark/07.png","url":"www.Vie.com"},{"id":8,"lightImage":"/img/clients/brands/light/08.png","darkImage":"/img/clients/brands/dark/08.png","url":"www.Vie.com"}]');
// EXTERNAL MODULE: ./src/components/Split/index.jsx
var Split = __webpack_require__(8636);
;// CONCATENATED MODULE: ./src/components/Clients/clients.jsx

/* eslint-disable @next/next/no-img-element */ 


const Clients = ({ theme  })=>{
    var first = clients_namespaceObject.slice(0, clients_namespaceObject.length / 2);
    var second = clients_namespaceObject.slice(4, clients_namespaceObject.length);
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "clients section-padding",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-4 valign md-mb50",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "sec-head mb-0",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "wow fadeIn",
                                    "data-wow-delay": ".5s",
                                    children: "Best Features"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "wow mb-20 color-font",
                                    children: "Our Clients"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Our area of practice is quite wide: design, graphics, branding, development."
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-8",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "row bord",
                                    children: first.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-md-3 col-6 brands",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "item wow fadeIn",
                                                "data-wow-delay": `${item.id == 1 ? ".3" : item.id == 2 ? ".6" : item.id == 3 ? ".8" : item.id == 4 ? ".3" : ""}s`,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "img",
                                                    children: [
                                                        theme === "light" ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: item.lightImage,
                                                            alt: ""
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: item.darkImage,
                                                            alt: ""
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Split/* default */.Z, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "#0",
                                                                className: "link words chars splitting",
                                                                "data-splitting": true,
                                                                children: item.url
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        }, item.id)
                                    )
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "row",
                                    children: second.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: `${item.id == 5 ? "col-md-3 col-6 brands sm-mb30" : item.id == 6 ? "col-md-3 col-6 brands sm-mb30" : item.id == 7 ? "col-md-3 col-6 brands" : item.id == 8 ? "col-md-3 col-6 brands" : ""}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "item wow fadeIn",
                                                "data-wow-delay": `${item.id == 1 ? ".4" : item.id == 2 ? ".7" : item.id == 3 ? ".5" : item.id == 4 ? ".3" : ""}s`,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "img",
                                                    children: [
                                                        theme === "light" ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: item.lightImage,
                                                            alt: ""
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: item.darkImage,
                                                            alt: ""
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Split/* default */.Z, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "#0",
                                                                className: "link words chars splitting",
                                                                "data-splitting": true,
                                                                children: item.url
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        }, item.id)
                                    )
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const clients = (Clients);


/***/ }),

/***/ 8957:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_cardMouseEffect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(262);
/* harmony import */ var _common_thumparallax__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4076);

/* eslint-disable @next/next/no-img-element */ 


const MinimalArea = ()=>{
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        (0,_common_cardMouseEffect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(document.querySelectorAll(".feat .items"));
        setTimeout(()=>{
            (0,_common_thumparallax__WEBPACK_IMPORTED_MODULE_3__/* .thumparallaxDown */ .D)();
        }, 1000);
    }, []);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "min-area sub-bg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "img",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: "thumparallax-down",
                                src: "/img/about-us/about-section.webp",
                                alt: "about-us | AA Growth Grid"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-6 valign",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "content pt-0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "wow color-font",
                                    children: "About us."
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "wow txt",
                                    "data-splitting": true,
                                    children: "OUR VALUES SET US APART"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "feat",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "agility wow fadeInUp",
                                            "data-wow-delay": ".2s",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "1"
                                                        }),
                                                        " AGILITY "
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "AA Growth Grid is synonymous with agility. It's how we quickly adapt to market changes, internally and externally, to ensure products are always ideally positioned and our customers are provided with what they need. We have our fingers on every pulse in the supply and distribution, knowledge, and market chain. With rapid response and flexibility to our partner's and customer's needs, working with us helps you maximize productivity and minimize expense with no compromise on quality."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "wow knowledge fadeInUp",
                                            "data-wow-delay": ".6s",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "2"
                                                        }),
                                                        " KNOWLEDGE "
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Information is the driving force of our success. We prioritize learning and constantly improving our industry knowledge to remain a leading distribution company. Our proactive approach to seeking new information allows us to do more, make better decisions, create better value, and stand out amongst our competitors."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "wow dedication fadeInUp",
                                            "data-wow-delay": "1s",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "3"
                                                        }),
                                                        " DEDICATION "
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "We're truly dedicated to the growth and success of our customers and partners. Your goals become our vision, your challenges become our problem, and your needs become our actions. Through our expertise, we know how to help you arrive at your objectives and through our dedication, we can help you meet your ambitious business objectives."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MinimalArea);


/***/ }),

/***/ 8604:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_circular_progressbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1400);
/* harmony import */ var react_circular_progressbar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_circular_progressbar__WEBPACK_IMPORTED_MODULE_2__);




const SkillsCircle = ({ from , theme  })=>{
    const cpStyle = {
        path: {
            stroke: "rgb(18, 194, 233)"
        },
        trail: {
            stroke: theme ? theme == "dark" ? "#0f1013" : "#e5e5e5" : ""
        },
        text: {
            fill: theme ? theme == "dark" ? "#ffffff" : "#4e4e4e" : "",
            // Text size
            fontSize: "16px"
        }
    };
    return(/*#__PURE__*/ _jsx("section", {
        className: `skills-circle pt-50 pb-50 ${from ? from === "aboutPage" ? "sub-bg" : "" : ""}`,
        children: /*#__PURE__*/ _jsx("div", {
            className: "container",
            children: /*#__PURE__*/ _jsx("div", {
                className: "row",
                children: /*#__PURE__*/ _jsx("div", {
                    className: "col-lg-7",
                    children: /*#__PURE__*/ _jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ _jsxs("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ _jsx("div", {
                                    className: "col-md-6",
                                    children: /*#__PURE__*/ _jsxs("div", {
                                        className: "item wow fadeInLeft",
                                        "data-wow-delay": ".6",
                                        children: [
                                            /*#__PURE__*/ _jsx("div", {
                                                className: "skill",
                                                children: /*#__PURE__*/ _jsx(CircularProgressbar, {
                                                    value: 90,
                                                    strokeWidth: 2,
                                                    text: `${90}%`,
                                                    styles: cpStyle
                                                })
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "cont",
                                                children: [
                                                    /*#__PURE__*/ _jsx("span", {
                                                        children: "Project"
                                                    }),
                                                    /*#__PURE__*/ _jsx("h6", {
                                                        children: "Consulting"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ _jsx("div", {
                                    className: "col-md-6",
                                    children: /*#__PURE__*/ _jsxs("div", {
                                        className: "item wow fadeInLeft",
                                        "data-wow-delay": ".3",
                                        children: [
                                            /*#__PURE__*/ _jsx("div", {
                                                className: "skill",
                                                children: /*#__PURE__*/ _jsx(CircularProgressbar, {
                                                    value: 75,
                                                    strokeWidth: 2,
                                                    text: `${75}%`,
                                                    styles: cpStyle
                                                })
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "cont",
                                                children: [
                                                    /*#__PURE__*/ _jsx("span", {
                                                        children: "App"
                                                    }),
                                                    /*#__PURE__*/ _jsx("h6", {
                                                        children: "Development"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SkillsCircle)));


/***/ }),

/***/ 4522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ team)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./src/common/teamSkillsProgress.js
const teamSkillsProgress = ()=>{
    let teamSection = document.querySelector(".team-crv");
    if (teamSection) {
        window.addEventListener("scroll", ()=>{
            document.querySelectorAll(".skill-progress .progres").forEach((item)=>{
                let myVal = item.getAttribute("data-value");
                if (window.pageYOffset > teamSection.offsetTop - 200) {
                    item.style.width = myVal;
                }
            });
        });
    }
};
/* harmony default export */ const common_teamSkillsProgress = (teamSkillsProgress);

;// CONCATENATED MODULE: ./src/common/fadeInFadeOut.js
var opacity = 0;
var intervalID = 0;
const fadeIn = (el, time)=>{
    setInterval(show(el), time);
};
function show(el) {
    opacity = Number(window.getComputedStyle(el).getPropertyValue("opacity"));
    if (opacity < 1) {
        opacity = opacity + 1;
        el.style.opacity = opacity;
    } else {
        clearInterval(intervalID);
    }
}
const fadeOut = (el, time)=>{
    setInterval(hide(el), time);
};
function hide(el) {
    opacity = Number(window.getComputedStyle(el).getPropertyValue("opacity"));
    if (opacity > 0) {
        opacity = 0;
        el.style.opacity = opacity;
    } else {
        clearInterval(intervalID);
    }
}

;// CONCATENATED MODULE: ./src/common/tooltipEffect.js

const tooltipEffect = ()=>{
    let template1 = document.createElement("div");
    template1.classList.add("div-tooltip-tit");
    document.body.appendChild(template1);
    let template2 = document.createElement("div");
    template2.classList.add("div-tooltip-sub");
    document.body.appendChild(template2);
    document.querySelectorAll("[data-tooltip-tit]").forEach((item)=>{
        template1 = document.querySelector(".div-tooltip-tit");
        item.addEventListener("mouseover", ()=>{
            template1.innerText = item.getAttribute("data-tooltip-tit");
        });
        item.addEventListener("mousemove", (e)=>{
            fadeIn(template1, 800);
            template1.style.top = e.pageY + 10 + "px";
            template1.style.left = e.pageX + 20 + "px";
            template1.style.padding = "0px 10px";
        });
        item.addEventListener("mouseleave", ()=>{
            fadeOut(template1, 800);
            template1.style.padding = 0;
        });
    });
    document.querySelectorAll("[data-tooltip-sub]").forEach((item)=>{
        template2 = document.querySelector(".div-tooltip-sub");
        item.addEventListener("mouseover", ()=>{
            template2.innerText = item.getAttribute("data-tooltip-sub");
        });
        item.addEventListener("mousemove", (e)=>{
            fadeIn(template2, 800);
            template2.style.top = e.pageY - 15 + "px";
            template2.style.left = e.pageX + 30 + "px";
            template2.style.padding = "5px 10px";
        });
        item.addEventListener("mouseleave", ()=>{
            fadeOut(template2, 800);
            template2.style.padding = 0;
        });
    });
};
/* harmony default export */ const common_tooltipEffect = (tooltipEffect);

;// CONCATENATED MODULE: ./src/data/sections/team.json
const team_namespaceObject = JSON.parse('{"f":[{"id":1,"image":"/img/team/1.jpg","title":"Stephanie Lawrence","sub":"CEO, Colabrio Media"},{"id":2,"image":"/img/team/2.jpg","title":"Alex Regelman","sub":"CEO, Colabrio Media"},{"id":3,"image":"/img/team/3.jpg","title":"Stacey Stamper","sub":"CEO, Colabrio Media"},{"id":4,"image":"/img/team/4.jpg","title":"Stephanie Lawrence","sub":"CEO, Colabrio Media"}],"n":[{"id":1,"text":"UI / UX Design","value":"90%"},{"id":2,"text":"Apps Development","value":"80%"}]}');
;// CONCATENATED MODULE: ./src/components/Team/team.jsx

/* eslint-disable @next/next/no-img-element */ 



const Team = ()=>{
    external_react_default().useEffect(()=>{
        common_teamSkillsProgress();
        setTimeout(()=>{
            common_tooltipEffect();
        }, 1000);
    }, []);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "team-crv section-padding",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-5 valign",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "content wow fadeInUp md-mb30",
                            "data-wow-delay": ".5s",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "sub-title",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                            children: "Our Staff"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "co-tit mb-15",
                                    children: "We help to create visual strategies."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "We are Vie. We create award-winning websites, remarkable brands and cutting-edge apps.Nullam imperdie."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "skills-box mt-40",
                                    children: team_namespaceObject.n.map((skill)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "skill-item",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "custom-font",
                                                    children: skill.text
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "skill-progress",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "progres",
                                                        "data-value": skill.value
                                                    })
                                                })
                                            ]
                                        }, skill.id)
                                    )
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-6 offset-lg-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "img-box",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-sm-6 toright",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "full-width",
                                            children: team_namespaceObject.f.slice(0, 2).map((team, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `img sizxl ${index + 1 != team_namespaceObject.f.slice(0, 2).length ? "mb-30" : null}`,
                                                        "data-tooltip-tit": team.title,
                                                        "data-tooltip-sub": team.sub,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: team.image,
                                                            alt: "",
                                                            className: "imago wow"
                                                        })
                                                    })
                                                }, team.id)
                                            )
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-sm-6 toleft valign",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "full-width text-left",
                                            children: team_namespaceObject.f.slice(2, 4).map((team, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `img sizxl ${index + 1 != team_namespaceObject.f.slice(2, 4).length ? "mb-30" : null}`,
                                                        "data-tooltip-tit": team.title,
                                                        "data-tooltip-sub": team.sub,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                            src: team.image,
                                                            alt: "",
                                                            className: "imago wow"
                                                        })
                                                    })
                                                }, team.id)
                                            )
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const team = (Team);


/***/ })

};
;