"use strict";
exports.id = 675;
exports.ids = [675];
exports.modules = {

/***/ 764:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cards)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/Split/index.jsx
var Split = __webpack_require__(8636);
;// CONCATENATED MODULE: ./src/data/sections/homepage-cards.json
const homepage_cards_namespaceObject = JSON.parse('[{"id":1,"icon":"pe-7s-paint-bucket","image":"/img/partners/Partner-1.jpg","title":"3rd Party Sellers","description":"We are your strategic partners in navigating the dynamic world of Amazon FBA wholesale. We provide comprehensive support, from product sourcing and inventory management to optimized listings and robust marketing strategies. Our goal is to empower 3rd party sellers with the tools and insights they need to stand out, compete effectively, and achieve sustainable growth within the Amazon ecosystem.","content":["Amazon SEO.","Advertising & PPC For amazon.","Sponsored Product ads.","Sponsored Brand ads.","Sponsored Display ads."],"link":"/amazon-marketing-services","buttontext":"VIEW DETAILS"},{"id":2,"icon":"pe-7s-phone","image":"/img/partners/Partner-2.png","title":"Brands","description":"Unlock the full potential of your brand on Amazon with our tailored strategies and dedicated support. We specialize in boosting brand visibility, enhancing product listings, and implementing targeted advertising campaigns. Our mission is to showcase your brand\'s unique value, drive sales, and build a lasting presence in the competitive Amazon marketplace. Let us be your partner in achieving remarkable results and expanding your brand\'s reach.","content":["Finding Profitable Products.","Product Launches.","Amazon Product Ranking.","Listing Optimization.","EBC / A+ Content."],"link":"/brand-management-services","buttontext":"VIEW DETAILS"}]');
;// CONCATENATED MODULE: ./src/components/Cards/cards.jsx





const Cards = ({ style , lines  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: `services  bords section-padding ${style === "4item" ? "lficon" : lines ? "" : "pt-0"}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-8 col-md-10",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "margin-top-bottom-60 text-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "wow color-font",
                                children: "Our Partners"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        style === "4item",
                        homepage_cards_namespaceObject.map((feature)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-6 wow fadeInLeft",
                                "data-wow-delay": `${feature.id == 1 ? ".3" : feature.id === 2 ? ".7" : feature.id === 3 ? ".9" : ".9"}s`,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "item-box partners-item-box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: feature.link,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    className: "partners-image cursor-pointer",
                                                    src: feature.image
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "cont",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                    children: feature.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Split/* default */.Z, {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "wow txt mb-10 words chars splitting",
                                                            "data-splitting": true,
                                                            children: feature.description
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: feature.link,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "butn bord curve mt-30",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: feature.buttontext
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, feature.id)
                        )
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const cards = (Cards);


/***/ }),

/***/ 8477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ numbers)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./src/data/sections/fun-fact.json
const fun_fact_namespaceObject = JSON.parse('[{"id":1,"icon":"pe-7s-smile","content":"Managed Brand.","numberfront":"+","value":"50"},{"id":2,"icon":"pe-7s-portfolio","content":"Under Management","numberfront":"M+","value":"150"},{"id":3,"icon":"pe-7s-medal","content":"Product Launches.","numberfront":"+","value":"150"},{"id":4,"icon":"pe-7s-medal","content":"Passionate People.","numberfront":"+","value":"30"}]');
// EXTERNAL MODULE: ./src/components/Split/index.jsx
var Split = __webpack_require__(8636);
// EXTERNAL MODULE: external "react-countup"
var external_react_countup_ = __webpack_require__(609);
var external_react_countup_default = /*#__PURE__*/__webpack_require__.n(external_react_countup_);
// EXTERNAL MODULE: external "react-visibility-sensor"
var external_react_visibility_sensor_ = __webpack_require__(6882);
var external_react_visibility_sensor_default = /*#__PURE__*/__webpack_require__.n(external_react_visibility_sensor_);
;// CONCATENATED MODULE: ./src/components/Numbers/numbers.jsx






const Numbers = ()=>{
    external_react_default().useEffect(()=>{
        console.clear();
    });
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "number-sec section-padding",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-8 col-md-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "sec-head text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "wow fadeIn",
                                    "data-wow-delay": ".5s",
                                    children: "FUN FACTS"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "wow color-font",
                                    children: "Pleasure in the job puts perfection in the work."
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: fun_fact_namespaceObject.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "item no-bord sm-mb50",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: `icon ${item.icon}`
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                        className: "",
                                        children: [
                                            "\xa0",
                                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_countup_default()), {
                                                redraw: true,
                                                end: item.value,
                                                duration: "3",
                                                children: ({ countUpRef , start  })=>/*#__PURE__*/ jsx_runtime_.jsx((external_react_visibility_sensor_default()), {
                                                        onChange: start,
                                                        delayedCall: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "count",
                                                            ref: countUpRef
                                                        })
                                                    })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "count",
                                                children: [
                                                    " ",
                                                    item.numberfront
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Split/* default */.Z, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "wow txt words chars splitting",
                                            "data-splitting": true,
                                            children: item.content
                                        })
                                    })
                                ]
                            })
                        }, item.id)
                    )
                })
            ]
        })
    }));
};
/* harmony default export */ const numbers = (Numbers);


/***/ }),

/***/ 6272:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);

/* eslint-disable @next/next/no-img-element */ 

const Blogs1 = ()=>{
    return(/*#__PURE__*/ _jsx("section", {
        className: "blog section-padding sub-bg",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "container",
            children: [
                /*#__PURE__*/ _jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ _jsx("div", {
                        className: "col-lg-8 col-md-10",
                        children: /*#__PURE__*/ _jsxs("div", {
                            className: "sec-head text-center",
                            children: [
                                /*#__PURE__*/ _jsx("h6", {
                                    className: "wow fadeIn",
                                    "data-wow-delay": ".5s",
                                    children: "RECENT ARTICLES"
                                }),
                                /*#__PURE__*/ _jsx("h3", {
                                    className: "wow color-font",
                                    children: "From our blogs."
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ _jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ _jsxs("div", {
                                className: "item md-mb50 wow fadeInUp",
                                "data-wow-delay": ".3s",
                                children: [
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "img",
                                        children: /*#__PURE__*/ _jsx("img", {
                                            src: "/img/blog/1.jpg",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "cont",
                                        children: /*#__PURE__*/ _jsxs("div", {
                                            children: [
                                                /*#__PURE__*/ _jsxs("div", {
                                                    className: "info",
                                                    children: [
                                                        /*#__PURE__*/ _jsx(Link, {
                                                            href: "/blog/blog-dark",
                                                            children: /*#__PURE__*/ _jsx("a", {
                                                                className: "date",
                                                                children: /*#__PURE__*/ _jsxs("span", {
                                                                    children: [
                                                                        /*#__PURE__*/ _jsx("i", {
                                                                            children: "06"
                                                                        }),
                                                                        " August"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _jsx("span", {
                                                            children: "/"
                                                        }),
                                                        /*#__PURE__*/ _jsx(Link, {
                                                            href: "/blog/blog-dark",
                                                            children: /*#__PURE__*/ _jsx("a", {
                                                                className: "tag",
                                                                children: /*#__PURE__*/ _jsx("span", {
                                                                    children: "WordPress"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ _jsx("h5", {
                                                    children: /*#__PURE__*/ _jsx(Link, {
                                                        href: "/blog-details/blog-details-dark",
                                                        children: /*#__PURE__*/ _jsx("a", {
                                                            children: "How to use solid color combine with simple furnitures."
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ _jsx("div", {
                                                    className: "btn-more",
                                                    children: /*#__PURE__*/ _jsx(Link, {
                                                        href: "/blog-details/blog-details-dark",
                                                        children: /*#__PURE__*/ _jsx("a", {
                                                            className: "simple-btn",
                                                            children: "Read More"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ _jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ _jsxs("div", {
                                className: "item md-mb50 wow fadeInUp",
                                "data-wow-delay": ".5s",
                                children: [
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "img",
                                        children: /*#__PURE__*/ _jsx("img", {
                                            src: "/img/blog/2.jpg",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "cont",
                                        children: /*#__PURE__*/ _jsxs("div", {
                                            children: [
                                                /*#__PURE__*/ _jsxs("div", {
                                                    className: "info",
                                                    children: [
                                                        /*#__PURE__*/ _jsx(Link, {
                                                            href: "/blog/blog-dark",
                                                            children: /*#__PURE__*/ _jsx("a", {
                                                                className: "date",
                                                                children: /*#__PURE__*/ _jsxs("span", {
                                                                    children: [
                                                                        /*#__PURE__*/ _jsx("i", {
                                                                            children: "06"
                                                                        }),
                                                                        " August"
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _jsx("span", {
                                                            children: "/"
                                                        }),
                                                        /*#__PURE__*/ _jsx(Link, {
                                                            href: "/blog/blog-dark",
                                                            children: /*#__PURE__*/ _jsx("a", {
                                                                className: "tag",
                                                                children: /*#__PURE__*/ _jsx("span", {
                                                                    children: "WordPress"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ _jsx("h5", {
                                                    children: /*#__PURE__*/ _jsx(Link, {
                                                        href: "/blog-details/blog-details-dark",
                                                        children: /*#__PURE__*/ _jsx("a", {
                                                            children: "How to use solid color combine with simple furnitures."
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ _jsx("div", {
                                                    className: "btn-more",
                                                    children: /*#__PURE__*/ _jsx(Link, {
                                                        href: "/blog-details/blog-details-dark",
                                                        children: /*#__PURE__*/ _jsx("a", {
                                                            className: "simple-btn",
                                                            children: "Read More"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Blogs1)));


/***/ }),

/***/ 5675:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Navbar_navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4189);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Intro_with_slider_intro_with_slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6021);
/* harmony import */ var _components_About_us_about_us__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(259);
/* harmony import */ var _components_Numbers_numbers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8477);
/* harmony import */ var _components_Video_with_testimonials_video_with_testimonials__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2361);
/* harmony import */ var _components_blogs_Blogs1_blogs1__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6272);
/* harmony import */ var _data_app_json__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2806);
/* harmony import */ var _components_Call_to_action_call_to_action__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1565);
/* harmony import */ var _components_Footer_footer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3391);
/* harmony import */ var _layouts_Light__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(371);
/* harmony import */ var _components_Cards_cards__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(764);
/* harmony import */ var _components_Home_services_HomeServices__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8713);
/* harmony import */ var _components_video_background_video_background__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6323);
/* harmony import */ var _data_sections_introVideo_json__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3940);
/* harmony import */ var _data_sections_homeServices_json__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6383);
/* harmony import */ var _components_s_contact_form_s_contact_form__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5781);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_s_contact_form_s_contact_form__WEBPACK_IMPORTED_MODULE_18__, _components_video_background_video_background__WEBPACK_IMPORTED_MODULE_15__, _components_Intro_with_slider_intro_with_slider__WEBPACK_IMPORTED_MODULE_4__]);
([_components_s_contact_form_s_contact_form__WEBPACK_IMPORTED_MODULE_18__, _components_video_background_video_background__WEBPACK_IMPORTED_MODULE_15__, _components_Intro_with_slider_intro_with_slider__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






// import Services from "../components/Services/services";
// import Works from "../components/Works/works";

// import Testimonials from "../components/Testimonials/testimonials";

// import SkillsCircle from "../components/Skills-circle/skills-circle";
// import Clients from "../components/Clients/clients";











const Homepage = ()=>{
    const fixedSlider = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const MainContent = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const navbarRef = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    const logoRef = react__WEBPACK_IMPORTED_MODULE_1___default().useRef(null);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        setInterval(()=>{
            if (fixedSlider.current) {
                var slidHeight = fixedSlider.current.offsetHeight;
            }
            if (MainContent.current) {
                MainContent.current.style.marginTop = slidHeight + "px";
            }
        }, 1000);
        var navbar = navbarRef.current, logo = logoRef.current;
        if (window.pageYOffset > 300) {
            navbar.classList.add("nav-scroll");
        } else {
            navbar.classList.remove("nav-scroll");
        }
        window.addEventListener("scroll", ()=>{
            if (window.pageYOffset > 300) {
                navbar.classList.add("nav-scroll");
                logo.setAttribute("src", _data_app_json__WEBPACK_IMPORTED_MODULE_9__/* .darkLogo */ .Q1);
            } else {
                navbar.classList.remove("nav-scroll");
                logo.setAttribute("src", _data_app_json__WEBPACK_IMPORTED_MODULE_9__/* .lightLogo */ .E8);
            }
        });
    }, [
        fixedSlider,
        MainContent,
        navbarRef
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "AA Growth Grid | Strategic Consulting and Amazon Marketing Agency"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "AA Growth Grid Strategic Consulting and Amazon Marketing Agency. We Specialize in Amazon Wholesale.We accelorates Amazon Sellers and brands to new heights"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layouts_Light__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Navbar_navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        nr: navbarRef,
                        lr: logoRef
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_video_background_video_background__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                        sliderRef: fixedSlider,
                        data: _data_sections_introVideo_json__WEBPACK_IMPORTED_MODULE_16__
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        ref: MainContent,
                        className: "main-content",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Cards_cards__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_About_us_about_us__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Numbers_numbers__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home_services_HomeServices__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                data: _data_sections_homeServices_json__WEBPACK_IMPORTED_MODULE_17__,
                                heading: 'Why Choose AA Growth Grid?'
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Video_with_testimonials_video_with_testimonials__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    marginTop: "4rem"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_s_contact_form_s_contact_form__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                    heading: "Let AA Growth Grid be your trusted partner in achieving success on Amazon.",
                                    description: "Contact us today to learn more about how we can help your brand thrive and excel in the ever-evolving world of e-commerce."
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer_footer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Homepage);

});

/***/ }),

/***/ 6383:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"icon":"pe-7s-graph3","image":"/img/service-2.svg","title":"Data-Driven Strategies for Success","content1":"Success on Amazon isn\'t accidental; it\'s meticulously orchestrated. Our data-driven strategies are the compass that guides your journey. We dive deep into market trends, competitor analysis, and consumer behavior to craft strategies that position your products for maximum impact. With us, your decisions are backed by data, and your actions are aligned with Amazon success."},{"id":2,"icon":"pe-7s-flag","image":"/img/service-2.svg","title":"Market Penetration and Positioning","content1":"Entering the Amazon landscape requires finesse. Our market penetration strategies ensure your products break through the clutter, capturing the attention of your potential customers. We\'re not just about listing; we\'re about positioning – placing your brand in the spotlight where it belongs."},{"id":3,"image":"/img/service-2.svg","icon":"pe-7s-diamond","title":"Holistic Brand Growth","content1":"Our approach isn\'t just about boosting sales; it\'s about holistic brand growth. We sculpt your Amazon presence with attention to detail, curating a brand image that resonates across every touchpoint. From your product listings to your brand store, we\'re your architects of Amazon brand resonance."},{"id":4,"icon":"pe-7s-science","image":"/img/service-2.svg","title":"Sales Optimization and Scalability","content1":"Sales optimization isn\'t a one-time endeavor; it\'s a continuous evolution. Our strategies not only boost current sales but pave the way for scalable growth. We\'re your partners in amplifying conversions, enhancing listings, and navigating the algorithms that dictate Amazon\'s dynamics."},{"id":5,"icon":"pe-7s-repeat","image":"/img/service-2.svg","title":"Collaborate for Amazon Triumph","content1":"Every brand has a unique story to tell, and we\'re here to amplify yours. Let\'s collaborate, aligning our expertise with your brand\'s aspirations. Your Amazon journey is our priority, and together, we\'ll craft a saga of triumph that sets your brand apart."},{"id":6,"icon":"pe-7s-rocket","image":"/img/service-2.svg","title":"Experience the Difference","content1":"Discover the AA Growth Grid difference – where Amazon expertise, strategic insight, and dedication converge to drive results. Join us in igniting Amazon triumph, and let\'s script a success story that stands the test of time."}]');

/***/ }),

/***/ 3940:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"title":"AA Growth Grid accelorates Amazon Sellers and brands to new heights","content":"We are a group of professionals dedicated to consulting Amazon sellers and brands, navigating Amazon excellence: Your Brand\'s Guiding Light","video":"/videos/Home-main-video.mp4"}]');

/***/ })

};
;