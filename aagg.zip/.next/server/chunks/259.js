"use strict";
exports.id = 259;
exports.ids = [259];
exports.modules = {

/***/ 259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ about_us)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/Split/index.jsx
var Split = __webpack_require__(8636);
;// CONCATENATED MODULE: ./src/data/sections/about-us1.json
const about_us1_namespaceObject = JSON.parse('{"bH":"What We Do","TN":"Help you scale your business on Amazon","rx":"At AA Growth Grid, we\'re your partners in conquering Amazon\'s dynamic landscape. Our specialized expertise in Amazon FBA Wholesale empowers 3rd party sellers and brands with strategies that elevate their product sourcing, inventory management, and sales optimization. With a proven track record of propelling businesses to the forefront of Amazon\'s bustling marketplace, we\'re your roadmap to Amazon FBA Wholesale mastery.","j$":"We\'re not just consultants; we\'re your brand\'s voice, strategy, and growth catalyst. Our dedication to boosting brands\' sales and visibility on Amazon is unwavering. Through a blend of data-driven insights, strategic optimizations, and targeted marketing techniques, we craft a narrative that resonates with your brand\'s ethos and captivates your target audience.","BH":"/img/about-us.jpg"}');
;// CONCATENATED MODULE: ./src/components/About-us/about-us.jsx

/* eslint-disable @next/next/no-img-element */ 



const AboutUs = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "about-us section-padding",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-5 valign md-mb50",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-50",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        className: "fw-100 text-u ls10 mb-10",
                                        children: about_us1_namespaceObject.bH
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "fw-600 text-u ls1 mb-30 color-font",
                                        children: about_us1_namespaceObject.TN
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: about_us1_namespaceObject.rx
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-7 img",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: about_us1_namespaceObject.BH,
                                alt: ""
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-12 valign md-mb50",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mb-50",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: about_us1_namespaceObject.j$
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/case-studies",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "butn bord curve mt-30",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "CASE STUDIES"
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const about_us = (AboutUs);


/***/ })

};
;