"use strict";
exports.id = 166;
exports.ids = [166];
exports.modules = {

/***/ 9702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Card_Right_Image)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/Split/index.jsx
var Split = __webpack_require__(8636);
;// CONCATENATED MODULE: ./src/data/sections/ServicesCardRightImage.json
const ServicesCardRightImage_namespaceObject = JSON.parse('{"rx":"At AA Growth Grid, we are dedicated to helping brands succeed and thrive on the world\'s largest online marketplace - Amazon.","j$":"Whether you\'re an established brand or a third-party seller looking to boost your presence on Amazon, we have tailored solutions to meet your needs and exceed your expectations.","BH":"/img/about-us.jpg"}');
;// CONCATENATED MODULE: ./src/components/Card-right-image/Card-Right-Image.jsx

/* eslint-disable @next/next/no-img-element */ 



const CardRightImage = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "about-us section-padding",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-5 valign md-mb50",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-50",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: ServicesCardRightImage_namespaceObject.rx
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: ServicesCardRightImage_namespaceObject.j$
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-7 img",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: ServicesCardRightImage_namespaceObject.BH,
                            alt: ""
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const Card_Right_Image = (CardRightImage);


/***/ }),

/***/ 3325:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"icon":"pe-7s-paint-bucket","image":"/img/service-2.svg","title":"Product Listings","content1":"We optimize your product listings to maximize visibility and conversion rates."},{"id":2,"icon":"pe-7s-box1","image":"/img/service-2.svg","title":"Inventory Management","content1":"We help you maintain optimal inventory levels to avoid stockouts and overstock issues."},{"id":3,"image":"/img/service-2.svg","icon":"pe-7s-calculator","title":"Pricing Strategies","content1":"We implement pricing strategies to keep your products competitive while maintaining healthy profit margins."},{"id":4,"image":"/img/service-2.svg","icon":"pe-7s-config","title":"Supply Chain Optimization","content1":"We streamline your supply chain processes to minimize costs and improve efficiency."},{"id":5,"image":"/img/service-2.svg","icon":"pe-7s-shopbag","title":"Brand Store Creation","content1":"We create stunning, customized brand stores that showcase your products in an appealing and brand-consistent manner."},{"id":6,"image":"/img/service-2.svg","icon":"pe-7s-photo","title":"A+ Content","content1":"Our team develops engaging A+ content to highlight product features and benefits, increasing shopper confidence."},{"id":7,"image":"/img/service-2.svg","icon":"pe-7s-comment","title":"Review Management","content1":"We monitor and manage product reviews to maintain a positive brand image."},{"id":8,"image":"/img/service-2.svg","icon":"pe-7s-world","title":"Advertising and Promotion","content1":"We create and manage targeted advertising campaigns to increase your brand\'s visibility and sales."},{"id":9,"image":"/img/service-2.svg","icon":"pe-7s-graph2","title":"Marketplace Strategy","content1":"We help you develop a winning strategy to increase sales and profitability."},{"id":10,"image":"/img/service-2.svg","icon":"pe-7s-cash","title":"Pricing Optimization","content1":"We implement pricing strategies to help you compete effectively and maximize your margins."},{"id":11,"image":"/img/service-2.svg","icon":"pe-7s-lock","title":"Account Management","content1":"Our team manages your Amazon seller account, ensuring it is always up to date and compliant with Amazon\'s policies."},{"id":12,"image":"/img/service-2.svg","icon":"pe-7s-rocket","title":"Negotiations and Deal-Making","content1":"We leverage our industry expertise to negotiate better deals and partnerships on your behalf."}]');

/***/ }),

/***/ 6250:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"icon":"pe-7s-star","image":"/img/service-2.svg","title":"Experience","content1":"With years of experience in the e-commerce and Amazon marketplace, we have a proven track record of success."},{"id":2,"icon":"pe-7s-users","image":"/img/service-2.svg","title":"Dedicated Team","content1":"Our team of experts is committed to your brand\'s success and growth on Amazon."},{"id":3,"image":"/img/service-2.svg","icon":"pe-7s-umbrella","title":"Tailored Solutions: ","content1":"We understand that each brand is unique, so we create customized strategies to meet your specific needs."},{"id":4,"image":"/img/service-2.svg","icon":"pe-7s-graph1","title":"Results-Driven","content1":"Our focus is on delivering tangible results - increased sales, improved brand visibility, and better profit margins."}]');

/***/ }),

/***/ 2748:
/***/ ((module) => {

module.exports = JSON.parse('{"id":1,"heading":"🚀 Your Amazon Success Partner! 🌟","description":"At AA Growth Grid, our extensive experience makes us your ultimate Amazon business ally, guiding you towards long-term success on Amazon and beyond. We excel in simplifying the complexities of the Amazon platform for brands and third-party sellers, guaranteeing your products connect with a wide and diverse customer audience. 🌐🛒 #AmazonSuccess"}');

/***/ })

};
;