"use strict";
(() => {
var exports = {};
exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 8691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
;// CONCATENATED MODULE: ./src/pages/api/postcontact.js

const filePath = "src/data/contactformdata/contactformentries.json";
const now = new Date();
const formattedDate = now.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "2-digit"
});
const formattedTime = now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
});
const formattedTimestamp = `${formattedDate} ${formattedTime}`;
async function handler(req, res) {
    if (req.method === 'POST') {
        // let data = await fs.promises.readdir('src/data/contactformdata');
        // console.log("data: ", data);
        const data = JSON.parse(external_fs_namespaceObject.readFileSync(filePath, "utf-8"));
        const newRecord = {
            id: data.length + 1,
            timestamp: formattedTimestamp,
            ...req.body
        };
        data.push(newRecord);
        external_fs_namespaceObject.writeFileSync(filePath, JSON.stringify(data));
        res.status(200).json("Data Submited Successfully");
    } else if (req.method === 'GET') {
        const data = JSON.parse(external_fs_namespaceObject.readFileSync(filePath, "utf-8"));
        res.status(200).json(data);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8691));
module.exports = __webpack_exports__;

})();