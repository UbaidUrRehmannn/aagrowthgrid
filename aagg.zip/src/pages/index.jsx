import React from "react";
import Homepage from "./home1-light";

const Home = () => {
  return (
    <>
      <Homepage />
    </>
  );
};

export default Home;
